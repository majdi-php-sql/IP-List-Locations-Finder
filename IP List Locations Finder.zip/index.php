<?php
// This code created for Badr Legal Translation & Typing by Majdi Awad - Sinor PHP & SQL Developer
function getGeolocationData($ip) {
    $apiUrl = "https://ipinfo.io/$ip/json";
    $data = file_get_contents($apiUrl);

    return json_decode($data, true);
}

$csvFile = 'ips.csv'; 
$csvData = file($csvFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);

// Start building the HTML table
$tableHtml = '<table border="1">
    <tr>
        <th>IP</th>
        <th>Country</th>
        <th>Region</th>
        <th>City</th>
        <th>Latitude</th>
        <th>Longitude</th>
        <th>Device</th>
        <th>OS</th>
        <th>Browser</th>
    </tr>';

foreach ($csvData as $ip) {
    $geolocationData = getGeolocationData($ip);

    if (!empty($geolocationData)) {
        $country = $geolocationData['country'];
        $region = $geolocationData['region'];
        $city = $geolocationData['city'];
        $latitude = $geolocationData['loc'];
        list($latitude, $longitude) = explode(',', $latitude);
        $device = 'N/A'; 
        $os = 'N/A'; 
        $browser = 'N/A'; 

        $tableHtml .= "
            <tr>
                <td>$ip</td>
                <td>$country</td>
                <td>$region</td>
                <td>$city</td>
                <td>$latitude</td>
                <td>$longitude</td>
                <td>$device</td>
                <td>$os</td>
                <td>$browser</td>
            </tr>";
    }
}

$tableHtml .= '</table>';

echo $tableHtml;
?>
